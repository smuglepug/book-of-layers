THE BOOK OF LAYERS - advance copy
Owen Osayi | Six Layers of Effective Influence | OCURP

Thanks for reading it early. What's inside:
  The_Book_of_Layers.epub          the full book (11 sections, ~8,200 words, epub reader or Calibre)
  The_Book_of_Layers_sample.pdf    shorter PDF version of the introduction + six-layer framework
  cover_ebook_1600x2071.jpg        the cover

The book page (sample, trailer, the six-layer framework in one glance):
  https://smuglepug.github.io/book-of-layers/

What I'd like from you (only if it earns it):
  1. If the book is live on Amazon by the time you finish, an honest review on
     the Amazon page. Amazon weighs the first 30 days of reviews more than
     anything else, so even two sentences helps more than you'd think.
  2. Either way, tell me which of the six layers you scored lowest on. That is
     the part I'm most curious about and it shapes what I write next.

No obligation to say anything positive. If a section is weak, say so - I'd rather
know now.

- Owen
